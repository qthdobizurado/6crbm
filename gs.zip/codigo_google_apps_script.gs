// ============================================================
// 6º COMANDO REGIONAL BOMBEIRO MILITAR
// Google Apps Script — Backend do Painel
// ============================================================
// INSTRUÇÕES DE IMPLANTAÇÃO:
// 1. Acesse script.google.com e crie um novo projeto
// 2. Cole todo este código substituindo o conteúdo existente
// 3. No menu: Implantações > Nova implantação
//    - Tipo: App da Web
//    - Executar como: Eu mesmo
//    - Quem pode acessar: Qualquer pessoa
// 4. Execute a função configurarProjeto() uma vez e autorize.
// 5. Se houver alterações manuais nas abas, execute instalarGatilhoAtualizacao().
// 6. Atualize/republique a implantação e mantenha a URL no config.js.
//
// O dashboard lê diretamente a aba API_DASHBOARD da própria planilha.
// O Apps Script fica responsável pelos envios e por reconstruir essa aba.
// ============================================================

// Planilha usada pelo app da web
const PLANILHA_ID = '1joVnP30F4b1A-JtsgSF2lp_goHjIFIQt_novCkYDikY';

// Nomes das abas da planilha
const ABA_DIARIO = 'QuadroDiario';
const ABA_MENSAL = 'DadosMensais';
const ABA_API_DASHBOARD = 'API_DASHBOARD';

// ============================================================
// 🔒  SENHA DE ACESSO RESTRITO — defina aqui, não no front-end
// ============================================================
const SENHA_SERVIDOR = 'cbmgo193';

// ============================================================
// CABEÇALHOS — criados automaticamente na primeira execução
// ============================================================
const CABECALHO_DIARIO = [
    'Timestamp', 'UnidadeId', 'Unidade',
    'EfetivoOrd', 'EfetivoAC4', 'EfetivoTotal',
    'OficialDia', 'Contato', 'VTRsAtivas'
];

const CABECALHO_MENSAL = [
    'Timestamp', 'UnidadeId', 'Unidade',
    'Comandante', 'Subcomandante',
    'Oficiais', 'Pracas', 'Operacional',
    'AdmOficiais', 'AdmPracas', 'Afastamentos',
    'VtrEmCondicoes', 'VtrManutencao', 'VtrBaixadas',
    'EmbEmCondicoes', 'EmbManutencao', 'EmbBaixadas',
    'MatDesencarcerador', 'MatDEA', 'MatDrone', 'MatCompressor', 'MatMergulho',
    'Efetivo', 'Especialistas', 'Viaturas', 'Embarcacoes',
    'Materiais', 'PlanoChamada', 'AreaAtuacao'
];

// A aba abaixo é a fonte pública e leve usada pelo site.
// Ela é reconstruída automaticamente após cada envio.
const CABECALHO_API_DASHBOARD = [
    'Tipo', 'UnidadeId', 'AtualizadoEm', 'DadosJson'
];

// ============================================================
// CORS — permite chamadas do HTML hospedado em qualquer origem
// ============================================================
function criarResposta(dados) {
    return ContentService
        .createTextOutput(JSON.stringify(dados))
        .setMimeType(ContentService.MimeType.JSON);
}

function formatarTimestamp(val) {
    if (!val) return null;
    if (typeof val === 'string' && val.includes('/')) return val;
    var d = new Date(val);
    if (isNaN(d.getTime())) return val.toString();
    var pad = function(n) { return String(n).padStart(2, '0'); };
    return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear()
         + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
}

function normalizarUnidadeId_(valor) {
    return valor === null || valor === undefined ? '' : String(valor).trim();
}

// ============================================================
// GET — leitura de dados (e fallback de gravação via GET)
// ============================================================
function doGet(e) {
    var acao      = (e && e.parameter && e.parameter.acao)      || '';
    var tipo      = (e && e.parameter && e.parameter.tipo)      || '';
    var unidadeId = (e && e.parameter && e.parameter.unidadeId) || '';
    var resultado;

    try {
        if (acao === 'verificarSenha') {
            var senhaEnviada = (e && e.parameter && e.parameter.senha) || '';
            resultado = { sucesso: senhaEnviada === SENHA_SERVIDOR };

        } else if (acao === 'gravar') {
            var raw   = (e && e.parameter && e.parameter.payload) || '{}';
            var dados = JSON.parse(decodeURIComponent(raw));
            if (dados.tipo === 'diario') {
                resultado = gravarDiario(dados);
            } else if (dados.tipo === 'mensal') {
                resultado = gravarMensal(dados);
            } else {
                resultado = { sucesso: false, mensagem: 'Tipo desconhecido: ' + dados.tipo };
            }
        } else if (tipo === 'diario' && unidadeId) {
            resultado = lerUltimoDiarioPorUnidade(unidadeId);
        } else if (tipo === 'mensal' && unidadeId) {
            resultado = lerUltimoMensalPorUnidade(unidadeId);
        } else if (tipo === 'diario') {
            resultado = lerUltimosDiarios();
        } else if (tipo === 'mensal') {
            resultado = lerUltimosMensais();
        } else {
            resultado = { sucesso: true, mensagem: 'API ativa' };
        }
    } catch(err) {
        resultado = { sucesso: false, mensagem: 'Erro: ' + err.message };
    }

    return criarResposta(resultado);
}

// ============================================================
// POST — recebe dados do formulário (envio principal)
// ============================================================
function doPost(e) {
    var resultado;
    try {
        var raw = '';
        if (e && e.postData) {
            raw = e.postData.contents || '';
            if (!raw && typeof e.postData.getDataAsString === 'function') {
                raw = e.postData.getDataAsString();
            }
        }
        if (!raw) raw = '{}';
        var dados = JSON.parse(raw);
        if (dados.acao === 'verificarSenha') {
            resultado = { sucesso: (dados.senha || '') === SENHA_SERVIDOR };
        } else if (dados.tipo === 'diario') {
            resultado = gravarDiario(dados);
        } else if (dados.tipo === 'mensal') {
            resultado = gravarMensal(dados);
        } else {
            resultado = { sucesso: false, mensagem: 'Tipo desconhecido' };
        }
    } catch (err) {
        resultado = { sucesso: false, mensagem: 'Erro: ' + err.message };
    }
    return criarResposta(resultado);
}

// ============================================================
// GRAVAR — Quadro Diário
// Mantém SOMENTE uma linha por unidade, independentemente da data.
// ============================================================
function gravarDiario(d) {
    var lock = LockService.getScriptLock();
    lock.waitLock(30000);

    try {
        var ss = SpreadsheetApp.openById(PLANILHA_ID);
        var aba = obterOuCriarAbaNoArquivo_(ss, ABA_DIARIO, CABECALHO_DIARIO);
        var unidadeIdRecebida = normalizarUnidadeId_(d.unidadeId);

        if (!unidadeIdRecebida) {
            return { sucesso: false, mensagem: 'UnidadeId não informado.' };
        }

        var dados = aba.getDataRange().getValues();
        var linhasDaUnidade = [];

        // A data não participa mais da busca. Qualquer registro anterior
        // da mesma unidade será substituído pelo envio atual.
        for (var i = 1; i < dados.length; i++) {
            var unidadeIdLinha = normalizarUnidadeId_(dados[i][1]);
            if (unidadeIdLinha === unidadeIdRecebida) {
                linhasDaUnidade.push(i + 1);
            }
        }

        var linha = [
            d.timestamp || new Date(), d.unidadeId, d.unidade,
            d.efetivoOrd, d.efetivoAc4, d.efetivoTotal,
            d.oficial, d.contato, d.vtrs
        ];

        if (linhasDaUnidade.length > 0) {
            // Reutiliza a primeira linha encontrada.
            var linhaDestino = linhasDaUnidade[0];
            aba.getRange(linhaDestino, 1, 1, linha.length).setValues([linha]);

            // Exclui todas as linhas antigas/duplicadas da unidade.
            // A exclusão ocorre de baixo para cima para não deslocar as linhas pendentes.
            for (var j = linhasDaUnidade.length - 1; j >= 1; j--) {
                aba.deleteRow(linhasDaUnidade[j]);
            }
        } else {
            aba.appendRow(linha);
        }

        // Garante que a gravação esteja visível antes de gerar o retrato público.
        SpreadsheetApp.flush();
        atualizarApiDashboard_(ss);

        return {
            sucesso: true,
            mensagem: linhasDaUnidade.length > 0
                ? 'Quadro Diário substituído. Foi mantido somente o envio mais atual da unidade.'
                : 'Quadro Diário salvo com sucesso.'
        };
    } finally {
        lock.releaseLock();
    }
}

// ============================================================
// GRAVAR — Dados Mensais
// Mantém SOMENTE uma linha por unidade, independentemente do mês.
// ============================================================
function gravarMensal(d) {
    var lock = LockService.getScriptLock();
    lock.waitLock(30000);

    try {
        var ss = SpreadsheetApp.openById(PLANILHA_ID);
        var aba = obterOuCriarAbaNoArquivo_(ss, ABA_MENSAL, CABECALHO_MENSAL);
        var unidadeIdRecebida = normalizarUnidadeId_(d.unidadeId);

        if (!unidadeIdRecebida) {
            return { sucesso: false, mensagem: 'UnidadeId não informado.' };
        }

        var dados = aba.getDataRange().getValues();
        var linhasDaUnidade = [];

        // O mês não participa mais da busca. Qualquer registro anterior
        // da mesma unidade será substituído pelo envio atual.
        for (var i = 1; i < dados.length; i++) {
            var unidadeIdLinha = normalizarUnidadeId_(dados[i][1]);
            if (unidadeIdLinha === unidadeIdRecebida) {
                linhasDaUnidade.push(i + 1);
            }
        }

        var linha = [
            d.timestamp || new Date(), d.unidadeId, d.unidade,
            d.comandante || '', d.subcomandante || '',
            d.oficiais, d.pracas, d.operacional,
            d.admOf, d.admPr, d.afastamentos,
            d.vtrOp, d.vtrMt, d.vtrIn,
            d.embOp, d.embMt, d.embIn,
            d.matDes, d.matDea, d.matDrone, d.matComp, d.matMerg,
            d.efetivo       || '[]',
            d.especialistas || '[]',
            d.viaturas      || '[]',
            d.embarcacoes   || '[]',
            d.materiais     || '[]',
            d.planoChamada  || '[]',
            d.areaAtuacao   || '[]'
        ];

        if (linhasDaUnidade.length > 0) {
            var linhaDestino = linhasDaUnidade[0];
            aba.getRange(linhaDestino, 1, 1, linha.length).setValues([linha]);

            for (var j = linhasDaUnidade.length - 1; j >= 1; j--) {
                aba.deleteRow(linhasDaUnidade[j]);
            }
        } else {
            aba.appendRow(linha);
        }

        // Garante que a gravação esteja visível antes de gerar o retrato público.
        SpreadsheetApp.flush();
        atualizarApiDashboard_(ss);

        return {
            sucesso: true,
            mensagem: linhasDaUnidade.length > 0
                ? 'Dados mensais substituídos. Foi mantido somente o envio mais atual da unidade.'
                : 'Dados mensais salvos com sucesso.'
        };
    } finally {
        lock.releaseLock();
    }
}

// ============================================================
// LER — último registro diário de uma unidade específica
// ============================================================
function lerUltimoDiarioPorUnidade(unidadeId) {
    try {
        var aba   = obterOuCriarAba(ABA_DIARIO, CABECALHO_DIARIO);
        var dados = aba.getDataRange().getValues();
        if (dados.length <= 1) return { sucesso: true, registro: null };

        var ultimo = null;
        for (var i = 1; i < dados.length; i++) {
            var uid = dados[i][1] ? dados[i][1].toString() : '';
            if (uid == unidadeId) {
                if (!ultimo || dados[i][0] > ultimo[0]) {
                    ultimo = dados[i];
                }
            }
        }

        if (!ultimo) return { sucesso: true, registro: null };

        return {
            sucesso: true,
            registro: {
                timestamp:    formatarTimestamp(ultimo[0]),
                unidadeId:    ultimo[1],
                unidade:      ultimo[2],
                efetivoOrd:   ultimo[3],
                efetivoAc4:   ultimo[4],
                efetivoTotal: ultimo[5],
                oficial:      ultimo[6],
                contato:      ultimo[7],
                vtrs:         ultimo[8]
            }
        };
    } catch(e) {
        return { sucesso: false, mensagem: e.message };
    }
}

// ============================================================
// LER — último registro mensal de uma unidade específica
// ============================================================
function lerUltimoMensalPorUnidade(unidadeId) {
    try {
        var aba   = obterOuCriarAba(ABA_MENSAL, CABECALHO_MENSAL);
        var dados = aba.getDataRange().getValues();
        if (dados.length <= 1) return { sucesso: true, registro: null };

        var cab = dados[0];
        var ultimo = null;
        for (var i = 1; i < dados.length; i++) {
            var uid = dados[i][1] ? dados[i][1].toString() : '';
            if (uid == unidadeId) {
                if (!ultimo || dados[i][0] > ultimo[0]) {
                    ultimo = dados[i];
                }
            }
        }

        if (!ultimo) return { sucesso: true, registro: null };

        var obj = {};
        cab.forEach(function(c, i) { obj[c] = ultimo[i]; });
        obj.Timestamp = formatarTimestamp(obj.Timestamp);
        return { sucesso: true, registro: obj };
    } catch(e) {
        return { sucesso: false, mensagem: e.message };
    }
}

// ============================================================
// LER — últimos registros diários (um por unidade)
// ============================================================
function lerUltimosDiarios() {
    try {
        var aba   = obterOuCriarAba(ABA_DIARIO, CABECALHO_DIARIO);
        var dados = aba.getDataRange().getValues();
        if (dados.length <= 1) return { sucesso: true, registros: [] };

        var mapa = {};
        for (var i = 1; i < dados.length; i++) {
            var uid = dados[i][1];
            if (!mapa[uid] || dados[i][0] > mapa[uid][0]) {
                mapa[uid] = dados[i];
            }
        }

        var registros = Object.values(mapa).map(function(r) {
            return {
                timestamp:    formatarTimestamp(r[0]),
                unidadeId:    r[1],
                unidade:      r[2],
                efetivoOrd:   r[3],
                efetivoAc4:   r[4],
                efetivoTotal: r[5],
                oficial:      r[6],
                contato:      r[7],
                vtrs:         r[8]
            };
        });

        return { sucesso: true, registros: registros };
    } catch(e) {
        return { sucesso: false, mensagem: e.message };
    }
}

// ============================================================
// LER — últimos registros mensais (um por unidade)
// ============================================================
function lerUltimosMensais() {
    try {
        var aba   = obterOuCriarAba(ABA_MENSAL, CABECALHO_MENSAL);
        var dados = aba.getDataRange().getValues();
        if (dados.length <= 1) return { sucesso: true, registros: [] };

        var mapa = {};
        for (var i = 1; i < dados.length; i++) {
            var uid = dados[i][1];
            if (!mapa[uid] || dados[i][0] > mapa[uid][0]) {
                mapa[uid] = dados[i];
            }
        }

        var cab = dados[0];
        var registros = Object.values(mapa).map(function(r) {
            var obj = {};
            cab.forEach(function(c, i) { obj[c] = r[i]; });
            obj.Timestamp = formatarTimestamp(obj.Timestamp);
            return obj;
        });

        return { sucesso: true, registros: registros };
    } catch(e) {
        return { sucesso: false, mensagem: e.message };
    }
}

// ============================================================
// API_DASHBOARD — retrato leve para leitura direta pelo site
// ============================================================
function lerUltimosDiariosDaAba_(aba) {
    var dados = aba.getDataRange().getValues();
    if (dados.length <= 1) return [];

    var mapa = {};
    for (var i = 1; i < dados.length; i++) {
        var uid = normalizarUnidadeId_(dados[i][1]);
        if (!uid) continue;
        if (!mapa[uid] || dados[i][0] > mapa[uid][0]) {
            mapa[uid] = dados[i];
        }
    }

    return Object.keys(mapa).map(function(uid) {
        var r = mapa[uid];
        return {
            timestamp:    formatarTimestamp(r[0]),
            unidadeId:    r[1],
            unidade:      r[2],
            efetivoOrd:   r[3],
            efetivoAc4:   r[4],
            efetivoTotal: r[5],
            oficial:      r[6],
            contato:      r[7],
            vtrs:         r[8]
        };
    });
}

function lerUltimosMensaisDaAba_(aba) {
    var dados = aba.getDataRange().getValues();
    if (dados.length <= 1) return [];

    var mapa = {};
    for (var i = 1; i < dados.length; i++) {
        var uid = normalizarUnidadeId_(dados[i][1]);
        if (!uid) continue;
        if (!mapa[uid] || dados[i][0] > mapa[uid][0]) {
            mapa[uid] = dados[i];
        }
    }

    var cab = dados[0];
    return Object.keys(mapa).map(function(uid) {
        var r = mapa[uid];
        var obj = {};
        cab.forEach(function(c, i) { obj[c] = r[i]; });
        obj.Timestamp = formatarTimestamp(obj.Timestamp);
        return obj;
    });
}

function atualizarApiDashboard_(ss) {
    ss = ss || SpreadsheetApp.openById(PLANILHA_ID);

    var abaDiario = obterOuCriarAbaNoArquivo_(ss, ABA_DIARIO, CABECALHO_DIARIO);
    var abaMensal = obterOuCriarAbaNoArquivo_(ss, ABA_MENSAL, CABECALHO_MENSAL);
    var abaApi = obterOuCriarAbaNoArquivo_(ss, ABA_API_DASHBOARD, CABECALHO_API_DASHBOARD);

    var diarios = lerUltimosDiariosDaAba_(abaDiario);
    var mensais = lerUltimosMensaisDaAba_(abaMensal);
    var atualizadoEm = new Date().toISOString();
    var linhas = [];

    linhas.push([
        'meta',
        'painel',
        atualizadoEm,
        JSON.stringify({ versao: 1, atualizadoEm: atualizadoEm })
    ]);

    diarios.forEach(function(registro) {
        linhas.push([
            'diario',
            String(registro.unidadeId || ''),
            atualizadoEm,
            JSON.stringify(registro)
        ]);
    });

    mensais.forEach(function(registro) {
        linhas.push([
            'mensal',
            String(registro.UnidadeId || ''),
            atualizadoEm,
            JSON.stringify(registro)
        ]);
    });

    // clearContents remove linhas antigas sem destruir a formatação da aba.
    abaApi.clearContents();
    abaApi.getRange(1, 1, 1, CABECALHO_API_DASHBOARD.length)
        .setValues([CABECALHO_API_DASHBOARD])
        .setFontWeight('bold')
        .setBackground('#CE1126')
        .setFontColor('#FFFFFF');

    if (linhas.length) {
        abaApi.getRange(2, 1, linhas.length, CABECALHO_API_DASHBOARD.length)
            .setNumberFormat('@')
            .setValues(linhas);
    }

    abaApi.setFrozenRows(1);
    SpreadsheetApp.flush();

    return {
        sucesso: true,
        atualizadoEm: atualizadoEm,
        diarios: diarios.length,
        mensais: mensais.length
    };
}

// Execute manualmente uma vez após colar este código.
// Cria as abas necessárias e gera o primeiro retrato do dashboard.
function configurarProjeto() {
    var lock = LockService.getScriptLock();
    lock.waitLock(30000);
    try {
        var ss = SpreadsheetApp.openById(PLANILHA_ID);
        obterOuCriarAbaNoArquivo_(ss, ABA_DIARIO, CABECALHO_DIARIO);
        obterOuCriarAbaNoArquivo_(ss, ABA_MENSAL, CABECALHO_MENSAL);
        obterOuCriarAbaNoArquivo_(ss, ABA_API_DASHBOARD, CABECALHO_API_DASHBOARD);
        return atualizarApiDashboard_(ss);
    } finally {
        lock.releaseLock();
    }
}

// Pode ser executada manualmente sempre que desejar reconstruir a API.
function atualizarApiDashboard() {
    var lock = LockService.getScriptLock();
    lock.waitLock(30000);
    try {
        return atualizarApiDashboard_(SpreadsheetApp.openById(PLANILHA_ID));
    } finally {
        lock.releaseLock();
    }
}

// Opcional: execute uma vez caso também altere QuadroDiario ou DadosMensais
// diretamente na planilha. O gatilho manterá API_DASHBOARD sincronizada.
function instalarGatilhoAtualizacao() {
    var existentes = ScriptApp.getProjectTriggers();
    existentes.forEach(function(gatilho) {
        if (gatilho.getHandlerFunction() === 'aoEditarPlanilha_') {
            ScriptApp.deleteTrigger(gatilho);
        }
    });

    ScriptApp.newTrigger('aoEditarPlanilha_')
        .forSpreadsheet(PLANILHA_ID)
        .onEdit()
        .create();

    return { sucesso: true, mensagem: 'Gatilho de atualização instalado.' };
}

function aoEditarPlanilha_(e) {
    if (!e || !e.range) return;
    var nomeAba = e.range.getSheet().getName();
    if (nomeAba !== ABA_DIARIO && nomeAba !== ABA_MENSAL) return;

    var lock = LockService.getScriptLock();
    if (!lock.tryLock(10000)) return;
    try {
        atualizarApiDashboard_(e.source || SpreadsheetApp.openById(PLANILHA_ID));
    } finally {
        lock.releaseLock();
    }
}

// ============================================================
// UTILITÁRIO — obtém ou cria aba com cabeçalho
// ============================================================
function obterOuCriarAbaNoArquivo_(ss, nomeAba, cabecalho) {
    var aba = ss.getSheetByName(nomeAba);

    if (!aba) {
        aba = ss.insertSheet(nomeAba);
        aba.getRange(1, 1, 1, cabecalho.length)
           .setValues([cabecalho])
           .setFontWeight('bold')
           .setBackground('#CE1126')
           .setFontColor('#FFFFFF');
        aba.setFrozenRows(1);
        aba.autoResizeColumns(1, cabecalho.length);
    }

    return aba;
}

function obterOuCriarAba(nomeAba, cabecalho) {
    var ss = SpreadsheetApp.openById(PLANILHA_ID);
    return obterOuCriarAbaNoArquivo_(ss, nomeAba, cabecalho);
}
