// ============================================================
// 6º COMANDO REGIONAL BOMBEIRO MILITAR
// Google Apps Script — Backend do Painel
// ============================================================
// INSTRUÇÕES DE IMPLANTAÇÃO:
// 1. Acesse script.google.com e crie um novo projeto
// 2. Cole todo este código substituindo o conteúdo existente
// 3. No menu: Implantações > Nova implantação
//    - Tipo: App da Web
//    - Executar como: Eu mesmo
//    - Quem pode acessar: Qualquer pessoa
// 4. Copie a URL gerada e cole no painel HTML:
//    - SCRIPT_URL_DIARIO  → URL deste script (mesmo para ambos)
//    - SCRIPT_URL_MENSAL  → URL deste script (mesmo para ambos)
// ============================================================

// Nomes das abas da planilha
const ABA_DIARIO  = 'QuadroDiario';
const ABA_MENSAL  = 'DadosMensais';

// ============================================================
// 🔒  SENHA DE ACESSO RESTRITO — defina aqui, não no front-end
// ============================================================
const SENHA_SERVIDOR = 'cbm6crbm';

// ============================================================
// CABEÇALHOS — criados automaticamente na primeira execução
// ============================================================
const CABECALHO_DIARIO = [
    'Timestamp', 'UnidadeId', 'Unidade',
    'EfetivoOrd', 'EfetivoAC4', 'EfetivoTotal',
    'OficialDia', 'Contato', 'VTRsAtivas'
];

const CABECALHO_MENSAL = [
    'Timestamp', 'UnidadeId', 'Unidade',
    'Comandante', 'Subcomandante',
    'Oficiais', 'Pracas', 'Operacional',
    'AdmOficiais', 'AdmPracas', 'Afastamentos',
    'VtrEmCondicoes', 'VtrManutencao', 'VtrBaixadas',
    'EmbEmCondicoes', 'EmbManutencao', 'EmbBaixadas',
    'MatDesencarcerador', 'MatDEA', 'MatDrone', 'MatCompressor', 'MatMergulho',
    'Efetivo', 'Especialistas', 'Viaturas', 'Embarcacoes',
    'Materiais', 'PlanoChamada', 'AreaAtuacao'
];

// ============================================================
// CORS — permite chamadas do HTML hospedado em qualquer origem
// ============================================================
function criarResposta(dados) {
    return ContentService
        .createTextOutput(JSON.stringify(dados))
        .setMimeType(ContentService.MimeType.JSON);
}

function formatarTimestamp(val) {
    if (!val) return null;
    if (typeof val === 'string' && val.includes('/')) return val;
    var d = new Date(val);
    if (isNaN(d.getTime())) return val.toString();
    var pad = function(n) { return String(n).padStart(2, '0'); };
    return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear()
         + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
}

// ============================================================
// GET — leitura de dados (e fallback de gravação via GET)
// ============================================================
function doGet(e) {
    var acao      = (e && e.parameter && e.parameter.acao)      || '';
    var tipo      = (e && e.parameter && e.parameter.tipo)      || '';
    var unidadeId = (e && e.parameter && e.parameter.unidadeId) || '';
    var resultado;

    try {
        if (acao === 'verificarSenha') {
            var senhaEnviada = (e && e.parameter && e.parameter.senha) || '';
            resultado = { sucesso: senhaEnviada === SENHA_SERVIDOR };

        } else if (acao === 'gravar') {
            var raw   = (e && e.parameter && e.parameter.payload) || '{}';
            var dados = JSON.parse(decodeURIComponent(raw));
            if (dados.tipo === 'diario') {
                resultado = gravarDiario(dados);
            } else if (dados.tipo === 'mensal') {
                resultado = gravarMensal(dados);
            } else {
                resultado = { sucesso: false, mensagem: 'Tipo desconhecido: ' + dados.tipo };
            }
        } else if (tipo === 'diario' && unidadeId) {
            resultado = lerUltimoDiarioPorUnidade(unidadeId);
        } else if (tipo === 'mensal' && unidadeId) {
            resultado = lerUltimoMensalPorUnidade(unidadeId);
        } else if (tipo === 'diario') {
            resultado = lerUltimosDiarios();
        } else if (tipo === 'mensal') {
            resultado = lerUltimosMensais();
        } else {
            resultado = { sucesso: true, mensagem: 'API ativa' };
        }
    } catch(err) {
        resultado = { sucesso: false, mensagem: 'Erro: ' + err.message };
    }

    return criarResposta(resultado);
}

// ============================================================
// POST — recebe dados do formulário (envio principal)
// ============================================================
function doPost(e) {
    var resultado;
    try {
        var raw = '';
        if (e && e.postData) {
            raw = e.postData.contents || '';
            if (!raw && typeof e.postData.getDataAsString === 'function') {
                raw = e.postData.getDataAsString();
            }
        }
        if (!raw) raw = '{}';
        var dados = JSON.parse(raw);
        if (dados.acao === 'verificarSenha') {
            resultado = { sucesso: (dados.senha || '') === SENHA_SERVIDOR };
        } else if (dados.tipo === 'diario') {
            resultado = gravarDiario(dados);
        } else if (dados.tipo === 'mensal') {
            resultado = gravarMensal(dados);
        } else {
            resultado = { sucesso: false, mensagem: 'Tipo desconhecido' };
        }
    } catch (err) {
        resultado = { sucesso: false, mensagem: 'Erro: ' + err.message };
    }
    return criarResposta(resultado);
}

// ============================================================
// GRAVAR — Quadro Diário
// ============================================================
function gravarDiario(d) {
    var aba = obterOuCriarAba(ABA_DIARIO, CABECALHO_DIARIO);

    var hoje = new Date().toLocaleDateString('pt-BR');
    var dados = aba.getDataRange().getValues();
    var linhaExistente = -1;

    for (var i = 1; i < dados.length; i++) {
        var ts   = dados[i][0] ? dados[i][0].toString() : '';
        var unId = dados[i][1] ? dados[i][1].toString() : '';
        if (ts.startsWith(hoje) && unId == d.unidadeId) {
            linhaExistente = i + 1;
            break;
        }
    }

    var linha = [
        d.timestamp, d.unidadeId, d.unidade,
        d.efetivoOrd, d.efetivoAc4, d.efetivoTotal,
        d.oficial, d.contato, d.vtrs
    ];

    if (linhaExistente > 0) {
        aba.getRange(linhaExistente, 1, 1, linha.length).setValues([linha]);
    } else {
        aba.appendRow(linha);
    }

    return { sucesso: true, mensagem: 'Quadro Diário salvo com sucesso.' };
}

// ============================================================
// GRAVAR — Dados Mensais
// ============================================================
function gravarMensal(d) {
    var aba = obterOuCriarAba(ABA_MENSAL, CABECALHO_MENSAL);

    var agora  = new Date();
    var pad    = function(n) { return String(n).padStart(2, '0'); };
    var mesAno = pad(agora.getMonth() + 1) + '/' + agora.getFullYear();

    var dados = aba.getDataRange().getValues();
    var linhaExistente = -1;

    for (var i = 1; i < dados.length; i++) {
        var ts   = dados[i][0] ? dados[i][0].toString() : '';
        var unId = dados[i][1] ? dados[i][1].toString() : '';
        var partes = ts.split(' ')[0].split('/');
        var tsMesAno = partes.length === 3 ? partes[1] + '/' + partes[2] : '';
        if (tsMesAno === mesAno && unId == d.unidadeId) {
            linhaExistente = i + 1;
            break;
        }
    }

    var linha = [
        d.timestamp, d.unidadeId, d.unidade,
        d.comandante || '', d.subcomandante || '',
        d.oficiais, d.pracas, d.operacional,
        d.admOf, d.admPr, d.afastamentos,
        d.vtrOp, d.vtrMt, d.vtrIn,
        d.embOp, d.embMt, d.embIn,
        d.matDes, d.matDea, d.matDrone, d.matComp, d.matMerg,
        d.efetivo       || '[]',
        d.especialistas || '[]',
        d.viaturas      || '[]',
        d.embarcacoes   || '[]',
        d.materiais     || '[]',
        d.planoChamada  || '[]',
        d.areaAtuacao   || '[]'
    ];

    if (linhaExistente > 0) {
        aba.getRange(linhaExistente, 1, 1, linha.length).setValues([linha]);
    } else {
        aba.appendRow(linha);
    }

    return { sucesso: true, mensagem: 'Dados mensais salvos com sucesso.' };
}

// ============================================================
// LER — último registro diário de uma unidade específica
// ============================================================
function lerUltimoDiarioPorUnidade(unidadeId) {
    try {
        var aba   = obterOuCriarAba(ABA_DIARIO, CABECALHO_DIARIO);
        var dados = aba.getDataRange().getValues();
        if (dados.length <= 1) return { sucesso: true, registro: null };

        var ultimo = null;
        for (var i = 1; i < dados.length; i++) {
            var uid = dados[i][1] ? dados[i][1].toString() : '';
            if (uid == unidadeId) {
                if (!ultimo || dados[i][0] > ultimo[0]) {
                    ultimo = dados[i];
                }
            }
        }

        if (!ultimo) return { sucesso: true, registro: null };

        return {
            sucesso: true,
            registro: {
                timestamp:    formatarTimestamp(ultimo[0]),
                unidadeId:    ultimo[1],
                unidade:      ultimo[2],
                efetivoOrd:   ultimo[3],
                efetivoAc4:   ultimo[4],
                efetivoTotal: ultimo[5],
                oficial:      ultimo[6],
                contato:      ultimo[7],
                vtrs:         ultimo[8]
            }
        };
    } catch(e) {
        return { sucesso: false, mensagem: e.message };
    }
}

// ============================================================
// LER — último registro mensal de uma unidade específica
// ============================================================
function lerUltimoMensalPorUnidade(unidadeId) {
    try {
        var aba   = obterOuCriarAba(ABA_MENSAL, CABECALHO_MENSAL);
        var dados = aba.getDataRange().getValues();
        if (dados.length <= 1) return { sucesso: true, registro: null };

        var cab = dados[0];
        var ultimo = null;
        for (var i = 1; i < dados.length; i++) {
            var uid = dados[i][1] ? dados[i][1].toString() : '';
            if (uid == unidadeId) {
                if (!ultimo || dados[i][0] > ultimo[0]) {
                    ultimo = dados[i];
                }
            }
        }

        if (!ultimo) return { sucesso: true, registro: null };

        var obj = {};
        cab.forEach(function(c, i) { obj[c] = ultimo[i]; });
        obj.Timestamp = formatarTimestamp(obj.Timestamp);
        return { sucesso: true, registro: obj };
    } catch(e) {
        return { sucesso: false, mensagem: e.message };
    }
}

// ============================================================
// LER — últimos registros diários (um por unidade)
// ============================================================
function lerUltimosDiarios() {
    try {
        var aba   = obterOuCriarAba(ABA_DIARIO, CABECALHO_DIARIO);
        var dados = aba.getDataRange().getValues();
        if (dados.length <= 1) return { sucesso: true, registros: [] };

        var mapa = {};
        for (var i = 1; i < dados.length; i++) {
            var uid = dados[i][1];
            if (!mapa[uid] || dados[i][0] > mapa[uid][0]) {
                mapa[uid] = dados[i];
            }
        }

        var registros = Object.values(mapa).map(function(r) {
            return {
                timestamp:    formatarTimestamp(r[0]),
                unidadeId:    r[1],
                unidade:      r[2],
                efetivoOrd:   r[3],
                efetivoAc4:   r[4],
                efetivoTotal: r[5],
                oficial:      r[6],
                contato:      r[7],
                vtrs:         r[8]
            };
        });

        return { sucesso: true, registros: registros };
    } catch(e) {
        return { sucesso: false, mensagem: e.message };
    }
}

// ============================================================
// LER — últimos registros mensais (um por unidade)
// ============================================================
function lerUltimosMensais() {
    try {
        var aba   = obterOuCriarAba(ABA_MENSAL, CABECALHO_MENSAL);
        var dados = aba.getDataRange().getValues();
        if (dados.length <= 1) return { sucesso: true, registros: [] };

        var mapa = {};
        for (var i = 1; i < dados.length; i++) {
            var uid = dados[i][1];
            if (!mapa[uid] || dados[i][0] > mapa[uid][0]) {
                mapa[uid] = dados[i];
            }
        }

        var cab = dados[0];
        var registros = Object.values(mapa).map(function(r) {
            var obj = {};
            cab.forEach(function(c, i) { obj[c] = r[i]; });
            obj.Timestamp = formatarTimestamp(obj.Timestamp);
            return obj;
        });

        return { sucesso: true, registros: registros };
    } catch(e) {
        return { sucesso: false, mensagem: e.message };
    }
}

// ============================================================
// UTILITÁRIO — obtém ou cria aba com cabeçalho
// ============================================================
function obterOuCriarAba(nomeAba, cabecalho) {
    var ss  = SpreadsheetApp.getActiveSpreadsheet();
    var aba = ss.getSheetByName(nomeAba);

    if (!aba) {
        aba = ss.insertSheet(nomeAba);
        aba.getRange(1, 1, 1, cabecalho.length)
           .setValues([cabecalho])
           .setFontWeight('bold')
           .setBackground('#CE1126')
           .setFontColor('#FFFFFF');
        aba.setFrozenRows(1);
        aba.autoResizeColumns(1, cabecalho.length);
    }

    return aba;
}

// ============================================================
// TESTE MANUAL — rode esta função no editor para testar
// ============================================================
function testarScript() {
    var resultDiario = gravarDiario({
        tipo: 'diario', unidadeId: 1, unidade: '12º BBM - Cidade de Goiás',
        timestamp: new Date().toLocaleString('pt-BR'),
        efetivoOrd: 6, efetivoAc4: 2, efetivoTotal: 8,
        oficial: 'Cap. Teste', contato: '(62) 99999-0000',
        vtrs: 'ABT-12, UR-205'
    });
    Logger.log('Diário: ' + JSON.stringify(resultDiario));

    var resultMensal = gravarMensal({
        tipo: 'mensal', unidadeId: 1, unidade: '12º BBM - Cidade de Goiás',
        timestamp: new Date().toLocaleString('pt-BR'),
        comandante: 'Maj. Teste Silva', subcomandante: 'Cap. Teste Souza',
        oficiais: 12, pracas: 45, operacional: 48,
        admOf: 6, admPr: 9, afastamentos: 8,
        vtrOp: 6, vtrMt: 2, vtrIn: 1,
        embOp: 3, embMt: 1, embIn: 0,
        matDes: 3, matDea: 4, matDrone: 2,
        matComp: 3, matMerg: 4
    });
    Logger.log('Mensal: ' + JSON.stringify(resultMensal));
}
